# NZBOT V46 FINAL RELEASE

Status:
FINAL

Main Flow:

Member
↓
Register
↓
Approve
↓
Catalog
↓
Order
↓
Payment
↓
Process
↓
Account sent privately
↓
Warranty
↓
Ranking
↓
Reward

Operational:
OPEN 08:00
CLOSE 00:00
