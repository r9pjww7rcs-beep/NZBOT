# INSTALL NZBOT TERMUX

pkg update
pkg install nodejs git

git clone REPOSITORY

cd NZBOT

npm install

cp .env.example .env

npm start

Scan QR WhatsApp.
